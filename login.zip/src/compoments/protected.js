import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';

export default function Protected(props) {
  const navigate = useNavigate();
  const {Component} = props;
  useEffect(()=>{
    let login = localStorage.getItem("token")
    if(!login){
      navigate("/login")
    }
  })
  return (

    <div><Component/></div>
  )
}
