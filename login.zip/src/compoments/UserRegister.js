import React, { useState } from 'react';
import Parse from 'parse';
import '../App.css';
import { useNavigate } from 'react-router-dom';
import { Button, Divider, Input } from 'antd';

export const UserRegistration = ({setdata}) => {
  // State variables
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
   const navigate = useNavigate();
//   const doUserRegistration = async function (e) {
//     // Note that these values come from state variables that we've declared before
//     // const usernameValue = username;
//     // const passwordValue = password;
//     try {
//         console.log(e.target.value)
//       // Since the signUp method returns a Promise, we need to call it using await
//     //  const createdUser = await Parse.User.signUp(usernameValue, passwordValue);
//     // if(usernameValue==""){
//     //     alert("Enter name")
//     // }
//     // if(passwordValue==""){
//     //     alert("Enter value")
//     // }
//       alert(
//          "successful register"
//         // `Success! User ${createdUser.getUsername()} was successfully created!`
//       );
//       return true;
//     } catch (error) {
//       // signUp can fail if any parameter is blank or failed an uniqueness check on the server
//       alert(`Error! ${error}`);
//       return false;
//     }
//   };

 const handle = async function(){
    localStorage.setItem('username', username);
    localStorage.setItem('Password', password);
    navigate("/login")

 }

const onSubmit = (e) => {
    e.preventDefault();
    
    const { username,password } = e.target.elements;
    
    let conFom = {
      username: username.value,
      password: password.value,
    
    };
   
    setdata(prev=>[...prev,conFom]);
  };

  return (
    <div>
      <div className="header">
        <img
          className="header_logo"
          alt="Back4App Logo"
          src={
            'https://blog.back4app.com/wp-content/uploads/2019/05/back4app-white-logo-500px.png'
          }
        />
        <p className="header_text_bold">{'Signup Page'}</p>
        <p className="header_text">{'User Registration'}</p>
      </div>
      <div className="container">
        <h2 className="heading">{'User Registration'}</h2>
        <Divider />
        <form onSubmit={onSubmit} className="form">
        <div className="form_wrapper">
          Username<input id="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            placeholder="Username"
            size="large"
            className="form_input"
          /><br></br>
          Password:<input id="password"
            value={password} 
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Password"
            size="large"
            type="password"
            className="form_input"
          />
        </div>
        
            
        <div className="form_buttons">
          <button onClick={handle}
            type="submit"
            className="form_button"
            color={'#208AEC'}
            size="large"
          >
            Sign Up
          </button>
          <br></br>
         
          <button onClick={()=>navigate('/login')}  type="primary"
            className="form_button"
            color={'#208AEC'}
            size="large" >SignIn</button>
           
         {localStorage.getItem('username') && (
            <div>
               Name: <p>{localStorage.getItem('username')}</p>
            </div>
         )}
         {localStorage.getItem('Password') && (
            <div>
               Password: <p>{localStorage.getItem('Password')}</p>
            </div>
         )}
        </div>
        </form>
      </div>
    </div>
  );
};