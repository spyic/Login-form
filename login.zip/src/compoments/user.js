import React from 'react'
import { useNavigate } from 'react-router-dom';
export default function User() {
    const navigate = useNavigate();
    const logout = async function(){
        localStorage.removeItem("token");
        navigate("/")
     }
  return (
    <div>login successfully:
          <button onClick={logout} type="submit">Logout</button>
    </div>
  )
}
