import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import { Routes,Route } from 'react-router-dom';
import { UserLogin } from './compoments/UserLogin';
import { UserRegistration } from './compoments/UserRegister';
import Parse from 'parse/dist/parse.min.js';
import User from './compoments/user';
import Logout from './compoments/logout';
import { useNavigate } from 'react-router-dom';
import Protected from './compoments/protected';

// Your Parse initialization configuration goes here

function App() {
  const [data,setdata] = useState([]);
  const PARSE_APPLICATION_ID = 'aPnKcd8I9r46MpCHRicvLIJ40dG6SRgdeqUBA4jv';
const PARSE_HOST_URL = 'https://parseapi.back4app.com';
const PARSE_JAVASCRIPT_KEY = 'UKOotkzWx93TrDUGgVko1QAzJZgNmLjXiQRGTdvg';
Parse.initialize(PARSE_APPLICATION_ID, PARSE_JAVASCRIPT_KEY);
Parse.serverURL = PARSE_HOST_URL;
const navigate = useNavigate()
  return (
    <div className="App">
              <Routes>
        <Route path="/"  element={<UserRegistration setdata={setdata}/>}/>
        <Route path="/login" element={ <UserLogin state={data} setdata={setdata}  />}/>
          <Route path="/user" element={<Protected Component={User}/>} />
         <Route path="/logout" element={<Logout/>}/>
      </Routes>  
    {/* {  
          localStorage.getItem("token") =="abc"?  <div>
          <Routes>
     
          </Routes>
        </div>:"user not logged in"
         } */}
     
    </div>
  );
}

export default App;
